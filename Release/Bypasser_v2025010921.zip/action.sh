#!/system/bin/sh
echo "Successfully execute the ``action.sh``. "
exit 0
