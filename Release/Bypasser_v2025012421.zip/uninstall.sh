#!/system/bin/sh
echo -e "Successfully executed the \`\`uninstall.sh\`\`. \n"
exit 0
