# Bypasser

This is a developing Magisk module for bypassing Android environment detection related to TMLP. The abbreviation "TMLP" stands for anything related to Twrp, Magisk, LSPosed, and Plugins. 

# Warning

Since the project is still developing, please do not install the module here until this warning is removed in the future. 
