#!/system/bin/sh
echo "Successfully execute the ``action.sh``. \n"
exit 0
