#!/system/bin/sh
MODDIR=${0%/*}
exit 0
