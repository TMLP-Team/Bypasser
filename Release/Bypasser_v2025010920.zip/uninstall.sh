#!/system/bin/sh
echo "Successfully execute the ``uninstall.sh``. \n"
exit 0
